# Local PostgreSQL integration (Prompt 0021)

## Prerequisites

- PostgreSQL 14+ (verified with **16.15**)
- Node.js 20+ with project dependencies installed via `npm ci --legacy-peer-deps`
- A **disposable** database (never production)

## Create a test database

```bash
sudo -u postgres psql -c "CREATE USER vajra_test WITH PASSWORD 'replace-me' CREATEDB;"
sudo -u postgres psql -c "CREATE DATABASE vajra_test OWNER vajra_test;"
sudo -u postgres psql -d vajra_test -c "GRANT ALL ON SCHEMA public TO vajra_test;"
```

## Environment

```bash
export DATABASE_URL='postgresql://vajra_test:replace-me@127.0.0.1:5432/vajra_test'
export VAJRA_PG_INTEGRATION=1
# Optional for API process:
# export TOTP_ENCRYPTION_KEY='a-long-random-test-only-secret'
```

Do not commit credentials. Prefer a local ignored `.env`.

## Migrate and generate

```bash
npx prisma generate
npx prisma migrate deploy
npx prisma migrate status
```

## Run tests

```bash
# Unit / in-memory suite (default)
npm test

# Real PostgreSQL integration suite
VAJRA_PG_INTEGRATION=1 DATABASE_URL="$DATABASE_URL" npm run test:pg
```

## Production fail-closed

With `NODE_ENV=production` or `APP_ENV=production`, the server:

- Requires a non-placeholder `DATABASE_URL`
- Connects to PostgreSQL at startup
- **Does not** fall back to in-memory identity storage

## Verified objects (after migrate deploy)

Tables include User, UserCredential, DeviceSession, Device, DeviceCredential, EnrollmentChallenge,
DeviceAuthNonce, DeviceHeartbeat, RemoteCommand, CommandResult, AuditLog, SecurityEvent,
Notification, ThreatCheck, ThreatIndicator, RiskAssessment, PasskeyCredential.

Views: `vw_device_security_posture`, `vw_command_audit_history`  
Functions: `fn_prevent_audit_log_mutation`, `fn_record_command_execution_result`  
Trigger: `trg_prevent_audit_log_mutation` on `AuditLog`
