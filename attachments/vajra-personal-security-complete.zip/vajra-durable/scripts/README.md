# VAJRA Scripts (`scripts/`)

**Status:** `FOUNDATION` (Prompt 0001)

Reserved for developer verification, schema validation, and workspace maintenance utilities. Use the root `npm run lint`, `npm test`, and `npm run build` scripts for standard verification.
